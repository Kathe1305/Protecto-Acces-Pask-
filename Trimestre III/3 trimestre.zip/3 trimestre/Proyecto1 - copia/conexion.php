<?php
$con= mysqli_connect ('localhost','root','','accespask');
$sql="INSERT INTO usuario(Nombre, idRol,contraseña)
VALUES('".$_POST["nom"]."','".$_POST["Rol"]."', '".$_POST["clave"]."')";
$resultado= mysqli_query ($con,$sql) ;
mysqli_close($con);

if($resultado){
    header("location:IniciarSesion.html");
}
?>