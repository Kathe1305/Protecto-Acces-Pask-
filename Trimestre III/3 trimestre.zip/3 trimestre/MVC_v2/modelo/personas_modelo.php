<?php

  
 class personas_modelo {
    private $db; 
    private $personas; 
    private $conexion;
    private $nombre;
    private $edad;
    private $estatura;

    public function __construct(){
            //$this->db=Conectar::conexion(); 
            $conexion=new mysqli("localhost", "root", "", "bd_04022022");
            $conexion->query("SET NAMES 'utf8'"); 
            
            $this->personas=array(); 
            $conexion=new mysqli("localhost", "root", "", "bd_04022022");
            $conexion->query("SET NAMES 'utf8'"); 
            $this->db=$conexion; 
            //return $conexion; 
        }

    public function set_person($nom, $edad, $estatura){
        $this->nombre= $nom;
        $this->edad= $edad;
        $this->estatura= $estatura;
    }    
    

    public function get_personas(){
        $consulta=$this->db->query("select * from personas;");
        while($filas=$consulta->fetch_assoc()){
            $this->personas[]=$filas;
        }
        return $this->personas;
    }

    public function set_personas(){
        $consulta=$this->db->query("insert into personas(nombre, edad, estatura) values('" . $this->nombre . "','" . $this->edad . "','" . $this->estatura . "')");
        echo "<script>alert('Registro Agregado')</script>";
        $consulta=$this->db->query("select * from personas;");
        //$consulta=$this->conexion->query("select * from personas;");
        while($filas=$consulta->fetch_assoc()){
            $this->personas[]=$filas;
        }
        return $this->personas;
    }

    
 }

?>