<?php

if(isset($_POST["Agregar"])) {
    $valor = $_POST["Agregar"];
    if ( $valor == "Agregar")
      {
         require_once("../modelo/personas_modelo.php");
         $per = new personas_modelo;
         $nom = $_POST['txtNombre'];
         $edad = $_POST['txtEdad'];
         $estatura = $_POST['txtEstatura'];
         $per->set_person($nom, $edad, $estatura);
         $per->set_personas();
         $datos=$per->get_personas(); 
          //Llamada a la vista 
         require_once("../vistas/personas_vista2.php");
      }
   }   
    else{
          //Llamada al modelo 
          require_once("./modelo/personas_modelo.php");
          $per=new personas_modelo(); 
          $datos=$per->get_personas(); 
          //Llamada a la vista 
          require_once("./vistas/personas_vista2.php");
       }  
       
    
?>