<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
     <form method="POST" action="../controlador/personas_controlador.php">
         <table>
              <tr>
                  <td>Nombre:</td>
                  <td><input type="text" name="txtNombre"></td>
              </tr>
              <tr>
                  <td>Edad:</td>
                  <td><input type="text" name="txtEdad"></td>
              </tr>  
              <tr>
                  <td>Estatura:</td>
                  <td><input type="text" name="txtEstatura"></td>
              </tr>
              <tr>
                  <td><input type="submit" value="Agregar" name="Agregar"></td>
              </tr>
         </table>
     </form>
</body>
</html>