


CREATE TABLE PERSONAS
(
  id integer not null auto_increment primary key,
  nombre varchar(50) not null,
  edad varchar(50) not null,
  estatura varchar(50) not null
);


insert into PERSONAS(nombre, edad, estatura) values('Heiver', '25', '1.76');
insert into PERSONAS(nombre, edad, estatura) values('Alejandro', '15', '1.56');
insert into PERSONAS(nombre, edad, estatura) values('Marybel', '24', '1.70');

