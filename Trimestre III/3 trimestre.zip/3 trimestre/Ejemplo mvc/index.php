<?php
require_once("db/db.php");
require_once("controlador/personas_controlador.php");
?>
