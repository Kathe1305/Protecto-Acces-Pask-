<?php
$con= mysqli_connect ('localhost','root','','accesspask');
$clave=MD5($_POST["clave"]);
$sql="INSERT INTO usuario(idRol, Nombre, Apellido, idDoc, documento, contraseña)
VALUES('".$_POST["Rol"]."', '".$_POST["nom"]."', '".$_POST["apellido"]."', '".$_POST["Doc"]."', '".$_POST["documento"]."','$clave')";
$resultado=mysqli_query ($con,$sql) ;
mysqli_close($con);

if($resultado){
    header("location:ADM.html");
}
?>