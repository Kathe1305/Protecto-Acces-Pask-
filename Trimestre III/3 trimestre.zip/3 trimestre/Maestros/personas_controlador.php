<?php
    //Llamada al modelo
    require_once("usuario.php");
    $usuario=new usuario_modelo();
    $datos=$usuario->get_usuario();

    //Llamada a la vista
    require_once("Maestros.php");
?> 