<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" type="img" href="img/pask.png" size="any">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="ADM.css" type="text/css" rel="stylesheet" />
    <style>
        #cuadro_texto {
            width: 20%;
            height: 600px;
        }

        #iconos {
            position: absolute;
            height: 600px;
            left: 17%;
            right: 0%;
            top: 20px;
        }

        #cuadro_texto2 {
            position: absolute;
            height: 600px;
            left: 20%;
            right: 0%;
            top: 200px;
        }

        #menu ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        #menu ul li {
            display: inline-block;
        }

        #menu ul li a {
            color: rgb(0, 0, 0);
            display: block;
            padding: 5px 35px;
            text-decoration: none;
            background-color: rgb(0, 0, 0);
            border-radius: 30px;
        }

        #menu ul li a:hover {
            background-color: rgba(0, 0, 0, 0.472);
        }

        #reg ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        #reg ul li {
            display: inline-block;
        }

        #reg ul li a {
            color: rgb(0, 0, 0);
            display: block;
            padding: 20px 60px;
            text-decoration: none;

        }

        #reg ul li a:hover {
            background-color: rgba(0, 0, 0, 0.472);
        }

        body,
        html {
            background-color: #fff;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            position: relative;
            font-size: 16px;
            font-family: 'RobotoCondensed';
            overflow: hidden;
        }
    </style>
</head>

<body style="background: rgb(255,244,0);
background: linear-gradient(180deg, rgba(255,244,0,1) 0%, rgba(0,0,0,1) 100%);">
    <br>
    <div id="cuadro_texto">
        <center>
            <img src="img/pask.png" width="160xp" height="160xp" style="border-radius: 10px;">
        </center>
    </div>
    <div id="iconos">
        <div id="menu">
            <center>
                <ul>
                    <li><a href="ADM.html">
                            <h4>
                                <p
                                    style="color: white; font-family:cursive; font-style: oblique; font-weight: 1000; font: size 60px;">
                                    Inicio</p>
                            </h4>
                        </a></li>
                    <li><a href="Cursos.html">
                            <h4>
                                <p
                                    style="color: white; font-family:cursive; font-style: oblique; font-weight: 1000; font: size 60px;">
                                    Cursos</p>
                            </h4>
                        </a></li>
                    <li><a href="index.php">
                            <h4>
                                <p
                                    style="color: white; font-family:cursive; font-style: oblique; font-weight: 1000; font: size 60px;">
                                    Maestros</p>
                            </h4>
                        </a></li>
                    <li><a href="registro.html">
                            <h4>
                                <p
                                    style="color: white; font-family:cursive; font-style: oblique; font-weight: 1000; font: size 60px;">
                                    Registrar usuario</p>
                            </h4>
                        </a></li>
                    <li><a href="cerrar_sesion.php">
                            <h4>
                                <p
                                    style="color: white; font-family:cursive; font-style: oblique; font-weight: 1000; font: size 60px;">
                                    Cerrar sesion</p>
                            </h4>
                        </a> </li>

                </ul>
            </center>
        </div>
    </div> <br>

    <br><br><br><br>
    <div id="cuadro_texto2">
        <center>
            <h3>
                <p
                    style=" font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; font-style:normal; font-weight: 1000; font: size 60px;">
                    Listado de maestros </p>
            </h3>
            <table class="table table-hover">
                <tr>
                    <td>Nombre</td>
                    <td>Apellido</td>
                    <td>Documento</td>
                </tr>
                <?php
        
        foreach ($datos as $dato  ){
            echo"<tr><td>".$dato['Nombre']."</td>";
            echo"<td>".$dato['Apellido']."</td>";
            echo"<td>".$dato['documento']."</td>"; 
            echo "<td><a   href='./vistas/formulario.html'>Editar</a></td>";
            echo "<td><a   href='eliminar.html'>Eliminar</a></td> </tr>";
        }
        ?>
              </table>
            
        </center>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
</body>

</html>