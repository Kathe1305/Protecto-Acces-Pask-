<?php
require_once("db.php");
require_once("personas_controlador.php");
?>
