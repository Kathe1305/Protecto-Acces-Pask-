

CREATE DATABASE BIBLIOTECA;
USE BIBLIOTECA;


CREATE TABLE libro
(
  id integer not null auto_increment primary key,
  nombre varchar(40) not null,
  autor varchar(40) not null,
  anio_edicion int not null
);
