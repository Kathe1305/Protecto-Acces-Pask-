<?php
include("conexion.php");
$rol=$_POST["idRol"];
$nombre=$_POST["Nombre"];
$clave=MD5($_POST["contraseña"]);
$query= mysqli_query($conexion, "SELECT * FROM accesspask.usuario WHERE idRol=$rol AND Nombre = '$nombre'  AND contraseña ='$clave'");
$nr = mysqli_num_rows($query);
if ($nr==1){
   session_start();
   if ($rol==1){
      /*echo "<script>window.location='../vistas/ADM.html'</script>";*/
      header("location: ../vistas/ADM.html");       
   }
    else if ($rol==2){
    /*echo "<script>window.location='../vistas/PRF.html' </script>";*/
    header("location: ../vistas/PRF.html");
     
   } 
   else if ($rol==3){
      /*echo "<script>window.location='../vistas/PRF.html' </script>";*/
      header("location: ../vistas/EST.html");
       
     } 
  
}
else {
    echo "<script>alert('Rol, nombre o clave incorrecto.'); window.location= '../vistas/IniciarSesion.html';</script>";
}
?>
