<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
<?php
$nombre=$_POST["nom"];
$clave=$_POST["clave"];
$usuario="Juanse";
$clave1=md5("1234");


if($nombre==$usuario and md5($clave==$clave1))

{
     header ("location:inicio.html");
}
else {
    echo "<h1><p style='background-color:red';>EL USUARIO ES INCORRECTO </p> <h1>";
    echo"".$clave1;
}
?>
</center>
</body>
</html>