<?php
$con= mysqli_connect ('localhost','root','','accespask');
if (empty($_POST['nom'])or empty($_POST['Rol'])){
    header("location:registro.html");
}else{
$sql="INSERT INTO usuario(idRol, Nombre, Apellido,  idDoc, contraseña)
VALUES('".$_POST["Rol"]."', '".$_POST["nom"]."', '".$_POST["apell"]."', '".$_POST["Doc"]."','".$_POST["clave"]."')";
$resultado= mysqli_query ($con,$sql) ;
mysqli_close($con);
}
if($resultado){
    header("location:IniciarSesion.html");
}
?>