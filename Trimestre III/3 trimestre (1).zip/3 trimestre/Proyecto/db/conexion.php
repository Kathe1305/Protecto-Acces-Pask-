<?php
$con= mysqli_connect ('localhost','root','','accesspask');
$clave=MD5($_POST["clave"]);
if (empty($_POST['nom'])or empty($_POST['Rol'])){
    header("location:registro.html");
}else{
$sql="INSERT INTO usuario(Nombre, Apellido, idRol, idDoc, documento, contraseña)
VALUES('".$_POST["nom"]."', '".$_POST["apellido"]."','".$_POST["Rol"]."', '".$_POST["Doc"]."', '".$_POST["documento"]."','clave')";
$resultado= mysqli_query ($con,$sql) ;
mysqli_close($con);
}
if($resultado){
    header("location:..");
}
?>